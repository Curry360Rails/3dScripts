# Topology-aware bridge inference (experimental)

Replace build_terrain.py, crossing_deck_groups.py, rail_elevation_inference.py and add rail_topology_inference.py in the same directory.

Run `python run_rail_pipeline.py --terrain --force-rebuild --no-ground-mask` if your runner passes --infer-rail-crossings. Direct call: `python build_terrain.py ... --infer-rail-crossings --rail-inference-mode topology --rail-stable-approach 20 --rail-max-turn 90 --deck-group-gap 5 --deck-parallel-angle 15 --deck-group-z-tolerance inf`.

The output railway_elevation_profiles.json contains corrected Z for original OSM node IDs, including switch nodes, and is compatible with buildAnylogicRailNetwork.py if its RAIL_PROFILES path points to the generated output folder.

Important limitations: 1 m sampled graph can be large; candidate search is bounded by max_states. Local branch selection is heuristic, and crossings with inconsistent endpoints can be rejected. Grouping by overall axis may reject strongly curved parallel tracks. Elevation conflicts at shared nodes are median-reconciled. This is not surveyed engineering geometry. Verify crossing_groups.geojson and inferred_crossings.csv before import. No live AnyLogic model is modified.
