"""Adaptive, crack-free terrain mesh from a DEM and GeoPackage corridor lines."""
import argparse
import csv
import struct
import shutil
import tempfile
import io
import bisect
import json
import math
import os
import time
from concurrent.futures import ProcessPoolExecutor
from collections import defaultdict
from rail_elevation_inference import infer_profiles, save_profiles, DEFAULTS
from rail_topology_inference import infer_topology_profiles
from crossing_deck_groups import group_crossings, save_groups, append_group_decks
from pathlib import Path

from tqdm.auto import tqdm

import numpy as np
import rasterio
from PIL import Image
from rasterio.enums import Resampling
from rasterio.transform import from_bounds
from rasterio.warp import reproject, transform_geom, calculate_default_transform
from rasterio.vrt import WarpedVRT
from rasterio.merge import merge
from contextlib import ExitStack

from shapely.geometry import LineString, MultiLineString, GeometryCollection, box, Polygon
from shapely.ops import unary_union
from shapely import constrained_delaunay_triangles
from shapely import from_wkb
from shapely.geometry import shape



def _project_dem_bounds(boundary_path, target_crs, padding):
    from rasterio.warp import transform_bounds
    data = json.loads(Path(boundary_path).read_text(encoding='utf-8-sig'))
    if data.get('type') == 'FeatureCollection':
        feats = data.get('features', [])
        if len(feats) != 1:
            raise ValueError('Boundary must contain one polygon feature')
        data = feats[0]['geometry']
    elif data.get('type') == 'Feature':
        data = data['geometry']
    if data.get('type') != 'Polygon':
        raise ValueError('Boundary must be a WGS84 Polygon')
    ring = data['coordinates'][0]
    west, east = min(p[0] for p in ring), max(p[0] for p in ring)
    south, north = min(p[1] for p in ring), max(p[1] for p in ring)
    projected = transform_bounds('EPSG:4326', target_crs, west, south, east, north, densify_pts=41)
    return (projected[0]-padding, projected[1]-padding,
            projected[2]+padding, projected[3]+padding), (west,south,east,north)


def _target_dem_crs(boundary_path, sources):
    # NAD83 UTM zone appropriate for contiguous US, matching 3DEP source data.
    # Without a boundary, use the first source CRS as before.
    if boundary_path:
        data = json.loads(Path(boundary_path).read_text(encoding='utf-8-sig'))
        if data.get('type') == 'FeatureCollection':
            data = data['features'][0]['geometry']
        elif data.get('type') == 'Feature':
            data = data['geometry']
        ring = data['coordinates'][0]
        lon = (min(p[0] for p in ring)+max(p[0] for p in ring))/2
        lat = (min(p[1] for p in ring)+max(p[1] for p in ring))/2
        if not (-180 <= lon <= 180 and 0 <= lat <= 84):
            raise ValueError('Automatic NAD83 UTM selection requires a northern-hemisphere boundary')
        zone = max(1, min(60, int((lon + 180)//6) + 1))
        return rasterio.crs.CRS.from_epsg(26900+zone)
    with rasterio.open(sources[0]) as ds:
        return ds.crs


def resolve_raster_input(value, kind, output, target_crs=None, refresh=False,
                         boundary_path=None, boundary_buffer=500.0, vrt_resolution=1.0):
    """Build a GDAL-readable VRT with Python stdlib + Rasterio; no GDAL CLI.

    Selected source TIFFs must share CRS, pixel dimensions and pixel-grid alignment.
    The VRT references TIFFs directly; no elevation pixels are copied.
    """
    import hashlib
    import xml.etree.ElementTree as ET
    from rasterio.warp import transform_bounds

    path = Path(value).expanduser().resolve()
    if path.is_file():
        if path.suffix.lower() not in ('.tif', '.tiff', '.vrt'):
            raise ValueError(f'Unsupported DEM input: {path}')
        return str(path), [str(path)]
    if not path.is_dir():
        raise FileNotFoundError(f'{kind} input not found: {path}')
    paths = sorted(p for p in path.rglob('*') if p.is_file() and p.suffix.lower() in ('.tif', '.tiff')
                   and '_raster_mosaics' not in p.parts)
    if not paths:
        raise ValueError(f'No DEM TIFFs found: {path}')
    if kind != 'DEM':
        raise ValueError('Imagery uses VirtualImagery, not resolve_raster_input')

    # Pick the CRS from an actual tile intersecting the boundary, not an assumed UTM zone.
    selected = []
    excluded = []
    if boundary_path:
        boundary_data = json.loads(Path(boundary_path).read_text(encoding='utf-8-sig'))
        if boundary_data.get('type') == 'FeatureCollection':
            boundary_data = boundary_data['features'][0]['geometry']
        elif boundary_data.get('type') == 'Feature':
            boundary_data = boundary_data['geometry']
        ring = boundary_data['coordinates'][0]
        bbox_ll = (min(p[0] for p in ring), min(p[1] for p in ring),
                   max(p[0] for p in ring), max(p[1] for p in ring))
    else:
        bbox_ll = None

    for src in tqdm(paths, desc='Checking DEM coverage', unit='file'):
        with rasterio.open(src) as ds:
            if ds.crs is None:
                excluded.append((str(src), 'missing CRS'))
                continue
            if bbox_ll is not None:
                bb = transform_bounds('EPSG:4326', ds.crs, *bbox_ll, densify_pts=41)
                # buffer in projected units; the CRS is checked below
                if (ds.bounds.right <= bb[0]-boundary_buffer or
                    ds.bounds.left >= bb[2]+boundary_buffer or
                    ds.bounds.top <= bb[1]-boundary_buffer or
                    ds.bounds.bottom >= bb[3]+boundary_buffer):
                    excluded.append((str(src), 'outside project'))
                    continue
            selected.append(src)
    if not selected:
        raise ValueError(f'No DEM tiles overlap boundary {boundary_path}; found {len(paths)} TIFFs')

    with rasterio.open(selected[0]) as first:
        crs = first.crs
        transform = first.transform
        dx, dy = abs(transform.a), abs(transform.e)
        ref_left, ref_top = transform.c, transform.f
        dtype = first.dtypes[0]
        if (not crs.is_projected or 'met' not in (crs.linear_units or '').lower()):
            raise ValueError(f'DEM must use a projected CRS in meters; got {crs}')
        if first.count != 1:
            raise ValueError(f'DEM must be single-band: {selected[0]}')
        if not transform.is_rectilinear or transform.a <= 0 or transform.e >= 0:
            raise ValueError(f'DEM must be north-up: {selected[0]}')

    # Different CRSs are intentionally rejected; Rasterio can still read the final VRT.
    # A simple mosaic VRT cannot resample/warp sources to a common grid.
    tiles = []
    for src in selected:
        with rasterio.open(src) as ds:
            if ds.crs != crs:
                raise ValueError(f'DEM CRS mismatch: {src} uses {ds.crs}; expected {crs}. '
                                 'Reproject the source separately or remove it from the project folder.')
            t = ds.transform
            if ds.count != 1 or ds.dtypes[0] != dtype:
                raise ValueError(f'DEM band count or dtype mismatch: {src}')
            if not t.is_rectilinear or t.a <= 0 or t.e >= 0:
                raise ValueError(f'DEM must be north-up: {src}')
            if abs(t.a-dx) > max(1e-7, dx*1e-6) or abs(t.e+dy) > max(1e-7, dy*1e-6):
                raise ValueError(f'DEM pixel resolution differs: {src}; expected {dx} x {dy} m')
            col_offset = (t.c-ref_left)/dx
            row_offset = (ref_top-t.f)/dy
            if abs(col_offset-round(col_offset)) > 1e-4 or abs(row_offset-round(row_offset)) > 1e-4:
                raise ValueError(f'DEM pixel grids are not aligned: {src}; '
                                 'reproject/resample this TIFF separately before building VRT')
            tiles.append((src, ds.width, ds.height, t.c, t.f, ds.nodata, ds.block_shapes[0]))

    if bbox_ll is not None:
        bounds = _project_dem_bounds(boundary_path, crs, boundary_buffer)[0]
    else:
        bounds = (min(t[3] for t in tiles), min(t[4]-t[2]*dy for t in tiles),
                  max(t[3]+t[1]*dx for t in tiles), max(t[4] for t in tiles))
    col0 = math.floor((bounds[0]-ref_left)/dx)
    col1 = math.ceil((bounds[2]-ref_left)/dx)
    row0 = math.floor((ref_top-bounds[3])/dy)
    row1 = math.ceil((ref_top-bounds[1])/dy)
    width, height = col1-col0, row1-row0
    if width <= 0 or height <= 0:
        raise ValueError('Invalid DEM VRT extent')
    origin_x, origin_y = ref_left+col0*dx, ref_top-row0*dy
    print(f'DEM preflight: {len(paths)} TIFFs found, {len(selected)} selected, '
          f'{len(excluded)} excluded; CRS {crs}; resolution {dx:g} x {dy:g} m', flush=True)

    cache_dir = output / '_raster_mosaics'
    cache_dir.mkdir(parents=True, exist_ok=True)
    dst = cache_dir / 'dem_mosaic.vrt'
    stamp = cache_dir / 'dem_mosaic.vrt.sources.json'
    metadata = [(str(p.resolve()), p.stat().st_size, p.stat().st_mtime_ns) for p in selected]
    fp = hashlib.sha256(json.dumps({'sources':metadata, 'crs':str(crs), 'bounds':bounds,
                                    'grid':[origin_x,origin_y,dx,dy,width,height]},
                                   sort_keys=True).encode()).hexdigest()
    if not refresh and dst.is_file() and stamp.is_file():
        try:
            if json.loads(stamp.read_text(encoding='utf-8'))['fingerprint'] == fp:
                with rasterio.open(dst) as check:
                    if check.crs == crs and check.count == 1 and check.width == width and check.height == height:
                        print(f'Reusing virtual DEM: {dst}', flush=True)
                        return str(dst), [str(x) for x in selected]
        except (OSError, ValueError, KeyError, rasterio.errors.RasterioError):
            pass

    vrt_dtype = {'uint8':'Byte','int8':'Int8','uint16':'UInt16','int16':'Int16',
                 'uint32':'UInt32','int32':'Int32','float32':'Float32','float64':'Float64',
                 'uint64':'UInt64','int64':'Int64'}.get(dtype)
    if not vrt_dtype:
        raise ValueError(f'Unsupported DEM data type for VRT: {dtype}')
    root = ET.Element('VRTDataset', rasterXSize=str(width), rasterYSize=str(height))
    ET.SubElement(root, 'SRS').text = crs.to_wkt()
    ET.SubElement(root, 'GeoTransform').text = f'{origin_x}, {dx}, 0, {origin_y}, 0, {-dy}'
    band = ET.SubElement(root, 'VRTRasterBand', dataType=vrt_dtype, band='1')
    ET.SubElement(band, 'NoDataValue').text = '-9999'
    # Later sources are placed first in the VRT, so the first sorted TIFF takes precedence
    # on overlap (GDAL's last SimpleSource normally wins).
    for src, sw, sh, sx, sy, nodata, block_shape in reversed(tiles):
        tile_col = round((sx-origin_x)/dx)
        tile_row = round((origin_y-sy)/dy)
        dest_x0, dest_y0 = max(0,tile_col), max(0,tile_row)
        dest_x1, dest_y1 = min(width,tile_col+sw), min(height,tile_row+sh)
        if dest_x1 <= dest_x0 or dest_y1 <= dest_y0:
            continue
        source = ET.SubElement(band, 'ComplexSource' if nodata is not None else 'SimpleSource')
        ET.SubElement(source, 'SourceFilename', relativeToVRT='0').text = str(src.resolve())
        ET.SubElement(source, 'SourceBand').text = '1'
        ET.SubElement(source, 'SourceProperties', RasterXSize=str(sw), RasterYSize=str(sh),
                      DataType=vrt_dtype, BlockXSize=str(block_shape[1]), BlockYSize=str(block_shape[0]))
        ET.SubElement(source, 'SrcRect', xOff=str(dest_x0-tile_col), yOff=str(dest_y0-tile_row),
                      xSize=str(dest_x1-dest_x0), ySize=str(dest_y1-dest_y0))
        ET.SubElement(source, 'DstRect', xOff=str(dest_x0), yOff=str(dest_y0),
                      xSize=str(dest_x1-dest_x0), ySize=str(dest_y1-dest_y0))
        if nodata is not None:
            ET.SubElement(source, 'NODATA').text = str(nodata)
    tmp = cache_dir / 'dem_mosaic.partial.vrt'
    ET.ElementTree(root).write(tmp, encoding='utf-8', xml_declaration=True)
    try:
        with rasterio.open(tmp) as check:
            if check.crs != crs or check.count != 1 or check.width != width or check.height != height:
                raise ValueError('Generated DEM VRT failed metadata validation')
            check.read(1, window=((0,1),(0,1)))
        tmp.replace(dst)
    finally:
        tmp.unlink(missing_ok=True)
    stamp.write_text(json.dumps({'fingerprint':fp,'sources':[str(x) for x in selected],
                                 'excluded':excluded,'crs':str(crs),'bounds':bounds,
                                 'resolution_m':[dx,dy]},indent=2),encoding='utf-8')
    print(f'Created DEM VRT without gdalwarp: {dst}', flush=True)
    return str(dst), [str(x) for x in selected]


class VirtualImagery:
    """On-demand virtual mosaic: source TIFFs stay untouched on disk.

    Each source is opened as a GDAL-backed Rasterio WarpedVRT in the DEM CRS.
    Only source footprints intersecting a requested output window are read.
    First source with valid data wins, matching the old merge(method='first').
    """
    def __init__(self, sources, target_crs):
        from rasterio.warp import transform_bounds
        self.sources = [str(Path(p).resolve()) for p in sources]
        self.crs = target_crs
        self.stack = ExitStack()
        self.items = []
        try:
            for path in tqdm(self.sources, desc='Indexing virtual imagery', unit='file'):
                ds = self.stack.enter_context(rasterio.open(path))
                if ds.crs is None or ds.count < 3:
                    raise ValueError(f'Imagery needs a CRS and at least 3 bands: {path}')
                vrt = self.stack.enter_context(WarpedVRT(
                    ds, crs=target_crs, resampling=Resampling.bilinear,
                    src_nodata=ds.nodata))
                # Use the source footprint, not the large full virtual grid.
                footprint = transform_bounds(ds.crs, target_crs, *ds.bounds, densify_pts=21)
                self.items.append((vrt, footprint))
        except Exception:
            self.stack.close()
            raise

    def close(self):
        self.stack.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb):
        self.close()

    def render(self, bounds, width, height):
        from rasterio.windows import from_bounds as window_from_bounds
        from rasterio.windows import Window
        from rasterio.enums import Resampling as R
        xmin, ymin, xmax, ymax = bounds
        result = np.zeros((height, width, 3), dtype=np.uint8)
        filled = np.zeros((height, width), dtype=bool)
        for vrt, (left, bottom, right, top) in self.items:
            if right <= xmin or left >= xmax or top <= ymin or bottom >= ymax:
                continue
            window = window_from_bounds(xmin, ymin, xmax, ymax, transform=vrt.transform)
            # Boundless reads are not supported by WarpedVRT in some Rasterio builds;
            # clip to the VRT extent and copy the relevant output pixel rectangle.
            x0 = max(0, int(math.floor((max(xmin, left) - xmin) / (xmax-xmin) * width)))
            x1 = min(width, int(math.ceil((min(xmax, right) - xmin) / (xmax-xmin) * width)))
            y0 = max(0, int(math.floor((ymax - min(ymax, top)) / (ymax-ymin) * height)))
            y1 = min(height, int(math.ceil((ymax - max(ymin, bottom)) / (ymax-ymin) * height)))
            if x1 <= x0 or y1 <= y0:
                continue
            sub_bounds = (
                xmin + x0*(xmax-xmin)/width,
                ymax - y1*(ymax-ymin)/height,
                xmin + x1*(xmax-xmin)/width,
                ymax - y0*(ymax-ymin)/height,
            )
            subwindow = window_from_bounds(*sub_bounds, transform=vrt.transform)
            data = vrt.read(indexes=[1,2,3], window=subwindow,
                            out_shape=(3,y1-y0,x1-x0),
                            resampling=R.bilinear, masked=True)
            mask = ~np.ma.getmaskarray(data).any(axis=0)
            # Explicit dataset mask guards against missing NoData metadata.
            source_mask = vrt.read_masks(1, window=subwindow,
                                         out_shape=(y1-y0,x1-x0),
                                         resampling=R.nearest) > 0
            mask &= source_mask
            free = mask & ~filled[y0:y1, x0:x1]
            if free.any():
                patch = result[y0:y1, x0:x1]
                patch[free] = np.moveaxis(np.asarray(data.filled(0)),0,-1)[free]
                filled[y0:y1, x0:x1][free] = True
            if filled.all():
                break
        return result


def resolve_imagery_virtual(value, target_crs):
    """Return TIFF paths without ever writing an imagery mosaic."""
    path = Path(value).expanduser().resolve()
    if path.is_file() and path.suffix.lower() in ('.tif', '.tiff'):
        sources = [path]
    elif path.is_dir():
        sources = sorted(p for p in path.rglob('*') if p.is_file() and p.suffix.lower() in ('.tif', '.tiff'))
    else:
        raise FileNotFoundError(f'Imagery TIFF or folder not found: {path}')
    if not sources:
        raise ValueError(f'No imagery TIFFs found under {path}')
    print(f'Using {len(sources)} source imagery TIFFs via on-demand WarpedVRT (no physical mosaic)', flush=True)
    return [str(p) for p in sources]

def load_lines(path, layers, target_crs, preserve_original_crs=False):
    import pyogrio
    from pyogrio.raw import read as read_raw

    available = pyogrio.list_layers(path)[:, 0].tolist()
    selected = layers or available
    missing = set(selected) - set(available)
    if missing:
        raise ValueError(f"Unknown GPKG layers: {sorted(missing)}")

    geometries = []
    for layer in tqdm(selected, desc="Reading GPKG layers", unit="layer"):
        info = pyogrio.read_info(path, layer=layer)
        source_crs = info.get('crs')

        if not source_crs:
            if preserve_original_crs:
                print(f"WARNING: Layer {layer!r} has no stored CRS; preserving original coordinates. "
                      "Confirm they use the DEM's CRS for correct alignment.")
            else:
                raise ValueError(f"Layer {layer!r} has no stored CRS; cannot safely reproject")
        elif preserve_original_crs:
            if rasterio.crs.CRS.from_user_input(source_crs) != rasterio.crs.CRS.from_user_input(target_crs):
                raise ValueError(f"Exact-vertex export requires matching CRS: {source_crs} != {target_crs}")

        _, _, wkbs, _ = read_raw(path, layer=layer, columns=[], read_geometry=True)
        for wkb in wkbs:
            if wkb is None:
                continue
            geom = from_wkb(wkb)
            if geom.is_empty:
                continue
            if preserve_original_crs:
                projected = geom
            else:
                same_crs = rasterio.crs.CRS.from_user_input(source_crs) == rasterio.crs.CRS.from_user_input(target_crs)
                projected = geom if same_crs else shape(transform_geom(source_crs, target_crs, geom.__geo_interface__))

            if projected.geom_type == 'LineString':
                geometries.append(projected)
            elif projected.geom_type == 'MultiLineString':
                geometries.extend(projected.geoms)
            elif projected.geom_type == 'GeometryCollection':
                geometries.extend(g for g in projected.geoms if g.geom_type == 'LineString')

    if not geometries:
        raise ValueError('No line geometries found in selected GPKG layers')
    return geometries, selected



def load_vector_lines(path, layers, target_crs, preserve_original_crs=False):
    """Read a single GPKG, Overpass JSON, GeoJSON, or KML vector source.

    GeoJSON, Overpass JSON, and KML coordinates are WGS84 lon/lat.
    Reproject X/Y into DEM CRS; preserve original vertex count and any Z.
    """
    path = Path(path)
    suffix = path.suffix.lower()
    if suffix == '.gpkg':
        return load_lines(str(path), layers, target_crs, preserve_original_crs)
    if layers:
        raise ValueError('--layer is supported only for GeoPackage inputs')
    geometries = []
    if suffix in ('.geojson', '.json'):
        data = json.loads(path.read_text(encoding='utf-8-sig'))
        if isinstance(data, dict) and isinstance(data.get('elements'), list):
            # Overpass raw OSM JSON: ways reference shared OSM node IDs.
            nodes = {e['id']: (e['lon'], e['lat']) for e in data['elements']
                     if e.get('type') == 'node' and 'lon' in e and 'lat' in e}
            missing = 0
            for element in data['elements']:
                if element.get('type') != 'way':
                    continue
                tags = element.get('tags', {})
                if not (tags.get('railway') or tags.get('highway')):
                    continue
                coords = []
                for node_id in element.get('nodes', []):
                    if node_id not in nodes:
                        missing += 1
                        break
                    coords.append(nodes[node_id])
                else:
                    if len(coords) >= 2:
                        geometries.append(LineString(coords))
            if missing:
                print(f'WARNING: {missing} OSM ways have missing referenced nodes; skipped.', flush=True)
        else:
            features = data.get('features', []) if data.get('type') == 'FeatureCollection' else [data]
            crs = data.get('crs') if isinstance(data, dict) else None
            if crs:
                name = crs.get('properties', {}).get('name', '')
                if name and rasterio.crs.CRS.from_user_input(name) != rasterio.crs.CRS.from_epsg(4326):
                    raise ValueError('GeoJSON source must be WGS84 (EPSG:4326)')
            for feature in features:
                geometry = feature.get('geometry') if feature.get('type') == 'Feature' else feature
                if geometry:
                    geometries.extend(_line_parts(shape(geometry)))
    elif suffix == '.kml':
        import xml.etree.ElementTree as ET
        root = ET.parse(path).getroot()
        for element in root.iter():
            if element.tag.rsplit('}', 1)[-1] != 'LineString':
                continue
            coord_el = next((child for child in element if child.tag.rsplit('}', 1)[-1] == 'coordinates'), None)
            if coord_el is None or not coord_el.text:
                continue
            coords = []
            for token in coord_el.text.split():
                values = token.split(',')
                if len(values) >= 2:
                    coords.append(tuple(float(v) for v in values[:3]))
            if len(coords) >= 2:
                geometries.append(LineString(coords))
    else:
        raise ValueError('Vector input must be .gpkg, .json (Overpass), .geojson, or .kml')
    if not geometries:
        raise ValueError(f'No railway/roadway polylines found in {path}')
    # Source coordinates are WGS84; DEM coordinates are projected meters.
    # Transform without densification, retaining original vertex order and Z.
    transformed = []
    for geom in tqdm(geometries, desc='Projecting network lines', unit='line'):
        projected = shape(transform_geom('EPSG:4326', target_crs, geom.__geo_interface__))
        transformed.extend(_line_parts(projected))
    print(f'Loaded {len(transformed):,} polylines from {path.name}', flush=True)
    return transformed, [path.name]


def _line_parts(geom):
    if geom.is_empty:
        return []
    if geom.geom_type == 'LineString':
        return [geom]
    if geom.geom_type in ('MultiLineString', 'GeometryCollection'):
        return [line for part in geom.geoms for line in _line_parts(part)]
    return []

def export_lines(geometries, dem, out, origin_x, origin_y, base, spacing, z_offset, preserve_z, exact_vertices=False, rail_profile=None):
    path = out / 'network_lines.obj'
    idx = 1
    count = 0
    # Project sampled vertices onto inferred spans to keep network_lines.obj in
    # agreement with corrected AnyLogic track Z (for rail-only OSM input).
    segments = []
    if rail_profile:
        from shapely.strtree import STRtree
        for crossing in rail_profile.get('crossings', []):
            points = crossing['profile_xyz']
            for a,b in zip(points,points[1:]):
                line = LineString([(a[0],a[1]),(b[0],b[1])])
                if line.length > 1e-6:
                    segments.append((line,a[2],b[2]))
        segment_tree = STRtree([x[0] for x in segments]) if segments else None
    else:
        segment_tree = None
    with path.open('w', encoding='utf-8') as obj:
        obj.write('# Polyline edges only (not rendered surfaces)\n')
        obj.write('o Transport_Lines\n')
        for geom in tqdm(geometries, desc="Exporting rail/road lines", unit="line"):
            raw = list(geom.coords)
            if len(raw) < 2:
                continue
            if exact_vertices:
                # 2D OSM lines keep their original vertex count; Z is sampled from DEM.
                pts = raw
            else:
                pts = [raw[0]]
                for a, b in zip(raw, raw[1:]):
                    steps = max(1, math.ceil(math.hypot(b[0]-a[0], b[1]-a[1]) / spacing))
                    for j in range(1, steps+1):
                        t = j/steps
                        pts.append(tuple(a[k]+t*(b[k]-a[k]) for k in range(min(len(a),len(b)))))
            has_z = preserve_z and geom.has_z
            samples = None if has_z else dem.sample([(p[0],p[1]) for p in pts], indexes=1, masked=True)
            chain = []
            for j,p in enumerate(pts):
                z = p[2] if has_z else next(samples)[0]
                if segment_tree is not None and not has_z:
                    from shapely.geometry import Point
                    point = Point(p[0],p[1])
                    for si in segment_tree.query(point.buffer(0.25)):
                        line,z_a,z_b = segments[int(si)]
                        if line.distance(point) <= 0.05:
                            frac = line.project(point)/line.length
                            z = z_a + (z_b-z_a)*frac
                            break
                if np.ma.is_masked(z) or not np.isfinite(z) or (not has_z and dem.nodata is not None and z == dem.nodata):
                    if len(chain)>1: obj.write('l '+' '.join(map(str,chain))+'\n')
                    chain=[]
                    continue
                precision = 12 if exact_vertices else 5
                obj.write(f'v {p[0]-origin_x:.{precision}f} {p[1]-origin_y:.{precision}f} {float(z)-base+z_offset:.{precision}f}\n')
                chain.append(idx); idx+=1; count+=1
            if len(chain)>1:
                obj.write('l '+' '.join(map(str,chain))+'\n')
    print(f'Exported {count:,} line vertices to {path}', flush=True)



def read_corridors(path, layers, target_crs):
    from shapely.strtree import STRtree
    geometries, selected = load_vector_lines(path, layers, target_crs)
    return STRtree(geometries), selected, geometries


# Top-level quadtree tiles are independent; workers share a fixed integer lattice.
_REFINE = {}

def _init_refine(lines_wkb, bounds, near, middle, far, buffer, transition,
                 corridor_only, corridor_radius, dem_path, max_error, flat_spacing):
    from shapely import from_wkb
    from shapely.strtree import STRtree
    lines = [from_wkb(w) for w in lines_wkb]
    _REFINE.clear()
    _REFINE.update(tree=STRtree(lines), bounds=bounds, near=near, middle=middle,
                   far=far, buffer=buffer, transition=transition,
                   corridor_only=corridor_only, radius=corridor_radius,
                   dem_path=dem_path, max_error=max_error, flat_spacing=flat_spacing)


def _refine_task(task):
    from shapely.geometry import box
    ix_start, ix_end, j, scale, step = task
    w = _REFINE
    x0,y0,x1,y1 = w['bounds']
    tree = w['tree']
    cells = []
    dem = rasterio.open(w['dem_path']) if w['max_error'] is not None else None
    elevation_cache = {}

    def elevation(x,y):
        key=(round(x,5),round(y,5))
        if key not in elevation_cache:
            val = next(dem.sample([(min(x,dem.bounds.right-1e-7),
                                    min(y,dem.bounds.top-1e-7))], indexes=1, masked=True))[0]
            elevation_cache[key] = None if np.ma.is_masked(val) or not np.isfinite(val) or (dem.nodata is not None and val==dem.nodata) else float(val)
        return elevation_cache[key]

    def flat_enough(xa,ya,xb,yb):
        # Test five samples against the bilinear surface through the corners.
        # This is a sampled tolerance, NOT a rigorous bound on the entire DEM.
        z=[elevation(xa,ya), elevation(xb,ya), elevation(xa,yb), elevation(xb,yb)]
        if any(v is None for v in z): return False
        tests=[((xa+xb)/2,(ya+yb)/2,sum(z)/4),
               ((xa+xb)/2,ya,(z[0]+z[1])/2),
               ((xa+xb)/2,yb,(z[2]+z[3])/2),
               (xa,(ya+yb)/2,(z[0]+z[2])/2),
               (xb,(ya+yb)/2,(z[1]+z[3])/2)]
        return all((v:=elevation(x,y)) is not None and abs(v-est)<=w['max_error']
                   for x,y,est in tests)

    def subdivide(ix,iy,size):
        xa,ya=x0+ix*step,y0+iy*step
        xb,yb=min(x0+(ix+size)*step,x1),min(y0+(iy+size)*step,y1)
        if xa>=xb or ya>=yb:return
        footprint=box(xa,ya,xb,yb)
        if w['corridor_only']:
            nearby=tree.query(footprint.buffer(w['radius']))
            if not any(footprint.distance(tree.geometries[int(k)])<=w['radius'] for k in nearby):return
        candidates=tree.query(footprint.buffer(w['transition']))
        distance=min((footprint.distance(tree.geometries[int(k)]) for k in candidates),default=float('inf'))
        target=w['near'] if distance<=w['buffer'] else w['middle'] if distance<=w['transition'] else w['far']
        width=max(xb-xa,yb-ya)
        should_split=width>target and size>1
        if should_split and dem is not None and width<=w['flat_spacing'] and flat_enough(xa,ya,xb,yb):
            should_split=False
        if should_split:
            half=size//2
            for dy in (0,half):
                for dx in (0,half):subdivide(ix+dx,iy+dy,half)
        else:cells.append((ix,iy,size))
    try:
        for i in range(ix_start,ix_end):subdivide(i*scale,j*scale,scale)
    finally:
        if dem is not None:dem.close()
    return cells


def build_cells(bounds, tree, near, middle, far, buffer, transition, max_cells,
                corridor_only=False, corridor_radius=100, workers=1,
                dem_path=None, max_error=None, flat_spacing=20,
                corridor_bounds=None, task_columns=16):
    from shapely import to_wkb
    x0,y0,x1,y1=bounds
    levels=max(1,math.ceil(math.log2(far/near)))
    scale=2**levels
    step=far/scale
    nx=math.ceil((x1-x0)/far)
    ny=math.ceil((y1-y0)/far)
    if corridor_only and corridor_bounds is not None:
        cx0,cy0,cx1,cy1=corridor_bounds
        # Restrict top-level work to the corridor, keeping DEM origin unchanged.
        i0=max(0,math.floor((cx0-x0)/far)-1)
        i1=min(nx,math.ceil((cx1-x0)/far)+1)
        j0=max(0,math.floor((cy0-y0)/far)-1)
        j1=min(ny,math.ceil((cy1-y0)/far)+1)
    else:i0,i1,j0,j1=0,nx,0,ny
    tasks=[(i,min(i+task_columns,i1),j,scale,step)
           for j in range(j0,j1) for i in range(i0,i1,task_columns)]
    print(f'Refinement: {len(tasks):,} blocks, {workers} workers, lattice step {step:.4f} m',flush=True)
    init=([to_wkb(g) for g in tree.geometries],bounds,near,middle,far,
          buffer,transition,corridor_only,corridor_radius,dem_path,max_error,flat_spacing)
    cells=[]
    if workers==1:
        _init_refine(*init)
        iterator=map(_refine_task,tasks)
        for part in tqdm(iterator,total=len(tasks),desc='Refining terrain blocks',unit='block'):
            cells.extend(part)
            if len(cells)>max_cells:raise ValueError(f'Exceeded --max-cells={max_cells:,}')
    else:
        with ProcessPoolExecutor(max_workers=workers,initializer=_init_refine,initargs=init) as pool:
            for part in tqdm(pool.map(_refine_task,tasks,chunksize=1),total=len(tasks),desc='Refining terrain blocks',unit='block'):
                cells.extend(part)
                if len(cells)>max_cells:raise ValueError(f'Exceeded --max-cells={max_cells:,}')
    return cells,step


def sample_dem_blockwise(dem, keys, bounds, step, batch_size=250000):
    # Read each raster block once per batch rather than call dem.sample millions of times.
    from rasterio.windows import Window
    elevations=np.full(len(keys),np.nan,dtype=np.float32)
    block_h,block_w=dem.block_shapes[0]
    transform=dem.transform
    if not transform.is_rectilinear:
        raise ValueError('Vectorized DEM sampling requires a north-up raster')
    for start in tqdm(range(0,len(keys),batch_size),desc='Sampling DEM blocks',unit='batch'):
        end=min(start+batch_size,len(keys))
        part=keys[start:end]
        xs=np.array([min(bounds.right-1e-7,bounds.left+k[0]*step) for k in part])
        ys=np.array([min(bounds.top-1e-7,bounds.bottom+k[1]*step) for k in part])
        cols=np.floor((xs-transform.c)/transform.a).astype(np.int64)
        rows=np.floor((ys-transform.f)/transform.e).astype(np.int64)
        good=(rows>=0)&(rows<dem.height)&(cols>=0)&(cols<dem.width)
        block_ids=(rows//block_h)*((dem.width+block_w-1)//block_w)+(cols//block_w)
        for bid in np.unique(block_ids[good]):
            indices=np.flatnonzero(good & (block_ids==bid))
            r0=int(rows[indices[0]]//block_h*block_h)
            c0=int(cols[indices[0]]//block_w*block_w)
            window=Window(c0,r0,min(block_w,dem.width-c0),min(block_h,dem.height-r0))
            arr=dem.read(1,window=window,masked=True)
            values=np.ma.asarray(arr[rows[indices]-r0,cols[indices]-c0])
            data=np.asarray(values.astype(np.float32).filled(np.nan),dtype=np.float32)
            if dem.nodata is not None:data[data==dem.nodata]=np.nan
            data[~np.isfinite(data)]=np.nan
            elevations[start+indices]=data
    return elevations


def mesh_topology(cells):
    horizontal = defaultdict(set)
    vertical = defaultdict(set)
    for x,y,s in tqdm(cells, desc="Indexing cell edges", unit="cell"):
        for yy in (y,y+s):
            horizontal[yy].update((x,x+s))
        for xx in (x,x+s):
            vertical[xx].update((y,y+s))
    hs = {k:sorted(v) for k,v in horizontal.items()}
    vs = {k:sorted(v) for k,v in vertical.items()}
    vertices = {}
    faces = []
    def index(point):
        if point not in vertices:
            vertices[point] = len(vertices)+1
        return vertices[point]
    for x,y,s in tqdm(cells, desc="Stitching triangles", unit="cell"):
        # Perimeter CCW; intermediate points from finer neighboring cells stitch edges.
        low = hs[y]; high = hs[y+s]; left = vs[x]; right = vs[x+s]
        bottom = low[bisect.bisect_left(low,x):bisect.bisect_right(low,x+s)]
        east = right[bisect.bisect_right(right,y):bisect.bisect_right(right,y+s)]
        top = high[bisect.bisect_left(high,x):bisect.bisect_left(high,x+s)]
        west = left[bisect.bisect_right(left,y):bisect.bisect_left(left,y+s)]
        ring = ([(v,y) for v in bottom] + [(x+s,v) for v in east]
                + [(v,y+s) for v in reversed(top)] + [(x,v) for v in reversed(west)])
        # Remove duplicate corners and any repeated vertices.
        ring = list(dict.fromkeys(ring))
        center = (x+s/2,y+s/2)
        ci = index(center)
        ids = [index(pt) for pt in ring]
        for a,b in zip(ids, ids[1:]+ids[:1]):
            if a != b:
                faces.append((ci,a,b))
    return vertices, faces


def polygon_parts(geom):
    if geom.is_empty:
        return
    if geom.geom_type == 'Polygon':
        if geom.area > 1e-9:
            yield geom
    elif hasattr(geom, 'geoms'):
        for g in geom.geoms:
            yield from polygon_parts(g)


# Workers receive immutable mesh data once, not with every task.
_WORK = {}


def _init_clip_worker(xy, valid, corridor_wkb, x0, y0, tile_m, xmax, ymax):
    from shapely import from_wkb, prepare
    corridor = from_wkb(corridor_wkb)
    prepare(corridor)
    _WORK.clear()
    _WORK.update(xy=xy, valid=valid, corridor=corridor,
                 x0=x0, y0=y0, tile_m=tile_m, xmax=xmax, ymax=ymax)


def _clip_batch(batch):
    from shapely.geometry import Polygon, box
    w = _WORK
    xy, valid, corridor = w['xy'], w['valid'], w['corridor']
    x0, y0, tile_m = w['x0'], w['y0'], w['tile_m']
    xmax, ymax = w['xmax'], w['ymax']
    results = defaultdict(list)
    tile_boxes = {}
    for a, c, d in batch:
        if not (valid[a-1] and valid[c-1] and valid[d-1]):
            continue
        tri = Polygon((xy[a-1], xy[c-1], xy[d-1]))
        if tri.area < 1e-10 or not corridor.intersects(tri):
            continue
        # Most triangles inside the corridor need NO polygon intersection.
        parts = (tri,) if corridor.covers(tri) else tuple(polygon_parts(tri.intersection(corridor)))
        for poly in parts:
            minx, miny, maxx, maxy = poly.bounds
            ix0 = max(0, math.floor((minx-x0)/tile_m))
            iy0 = max(0, math.floor((miny-y0)/tile_m))
            ix1 = min(math.ceil((xmax-x0)/tile_m)-1, math.floor((maxx-x0-1e-9)/tile_m))
            iy1 = min(math.ceil((ymax-y0)/tile_m)-1, math.floor((maxy-y0-1e-9)/tile_m))
            if ix0 == ix1 and iy0 == iy1:
                results[(ix0,iy0)].append((poly,(a,c,d)))
                continue
            for iy in range(iy0,iy1+1):
                for ix in range(ix0,ix1+1):
                    key=(ix,iy)
                    if key not in tile_boxes:
                        tile_boxes[key]=box(x0+ix*tile_m,y0+iy*tile_m,
                                            min(x0+(ix+1)*tile_m,xmax),
                                            min(y0+(iy+1)*tile_m,ymax))
                    tile=tile_boxes[key]
                    piece=poly if tile.covers(poly) else poly.intersection(tile)
                    for part in polygon_parts(piece):
                        results[key].append((part,(a,c,d)))
    return results



# Bridge geometry is derived from OSM ways and DEM approach elevations. This
# intentionally does NOT edit the bare-earth DEM or infer a clearance from layer tags.
def bridge_profiles(infrastructure_path, dem, corridor, approach_m=12.0,
                    min_clearance_m=0.0):
    """Return profiles for OSM-tagged bridge ways, retaining OSM node identities."""
    data = json.loads(Path(infrastructure_path).read_text(encoding='utf-8-sig'))
    if not isinstance(data, dict) or not isinstance(data.get('elements'), list):
        raise ValueError('Bridge input must be raw Overpass JSON with elements')
    elements = data['elements']
    nodes = {e['id']: (e['lon'], e['lat']) for e in elements
             if e.get('type') == 'node' and 'lon' in e and 'lat' in e}
    records = []
    for way in elements:
        if way.get('type') != 'way':
            continue
        tags = way.get('tags') or {}
        if str(tags.get('bridge', '')).lower() in ('', 'no', 'false', '0'):
            continue
        kind = 'railway' if tags.get('railway') == 'rail' else 'road' if tags.get('highway') else None
        if kind is None:
            continue
        ids = way.get('nodes') or []
        if len(ids) < 2 or any(n not in nodes for n in ids):
            continue
        xy = [nodes[n] for n in ids]
        projected = shape(transform_geom('EPSG:4326', dem.crs, {'type':'LineString','coordinates':xy}))
        coords = [(float(x), float(y)) for x,y,*_ in projected.coords]
        line = LineString(coords)
        if line.length < 0.1 or not line.intersects(corridor):
            continue
        # Sample just beyond the bridge endpoints, where the ground is more
        # likely to represent the approaches, not the void beneath the span.
        d = min(approach_m, max(1.0, line.length * 0.25))
        def approach(first):
            a,b = (coords[0],coords[1]) if first else (coords[-1],coords[-2])
            dx,dy = a[0]-b[0],a[1]-b[1]
            length = math.hypot(dx,dy)
            if length < 1e-9: return a
            return (a[0]+dx/length*d,a[1]+dy/length*d)
        sample_points = [approach(True),approach(False)]
        # At DEM edges, fall back to the bridge endpoint rather than discarding
        # an otherwise valid bridge. This is a lower-confidence estimate.
        used_endpoint_fallback = False
        for k, point in enumerate(sample_points):
            if not (dem.bounds.left <= point[0] < dem.bounds.right and
                    dem.bounds.bottom < point[1] <= dem.bounds.top):
                sample_points[k] = coords[0] if k == 0 else coords[-1]
                used_endpoint_fallback = True
        zvals=[]
        for value in dem.sample(sample_points, indexes=1, masked=True):
            z = value[0]
            zvals.append(None if np.ma.is_masked(z) or not np.isfinite(z) or
                         (dem.nodata is not None and z == dem.nodata) else float(z))
        if any(z is None for z in zvals):
            status = 'unresolved_missing_dem_approach'
            profile = []
        else:
            # Interpolate by cumulative arc length, not vertex index.
            lengths=[0.0]
            for a,b in zip(coords,coords[1:]):
                lengths.append(lengths[-1]+math.dist(a,b))
            profile = [[x,y,zvals[0]+(zvals[1]-zvals[0])*t/lengths[-1]]
                       for (x,y),t in zip(coords,lengths)]
            ground=[]
            for value in dem.sample(coords, indexes=1, masked=True):
                z=value[0]
                ground.append(None if np.ma.is_masked(z) or not np.isfinite(z) else float(z))
            clearance = [p[2]-g for p,g in zip(profile,ground) if g is not None]
            status = ('review_low_clearance' if clearance and min(clearance)<min_clearance_m
                      else 'review_endpoint_fallback' if used_endpoint_fallback
                      else 'estimated_from_approaches')
        records.append({'osm_way_id':way['id'], 'type':kind,
                        'osm_node_ids':ids, 'tags':tags,
                        'approach_z_m':zvals, 'profile_xyz':profile,
                        'length_m':line.length, 'status':status})
    return records


def save_bridge_profiles(out, records, dem_crs):
    (out/'bridge_profiles.json').write_text(json.dumps({
        'crs':str(dem_crs), 'method':'linear interpolation between DEM approach samples',
        'note':'Estimated geometry; not surveyed bridge-deck elevations.',
        'bridges':records}, indent=2),encoding='utf-8')
    with (out/'bridge_review.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f)
        writer.writerow(['osm_way_id','type','length_m','start_approach_z_m',
                         'end_approach_z_m','status','bridge_tag','layer'])
        for r in records:
            z=r['approach_z_m']
            writer.writerow([r['osm_way_id'],r['type'],round(r['length_m'],2),
                             z[0],z[1],r['status'],r['tags'].get('bridge',''),r['tags'].get('layer','')])


def bridge_deck_mesh(record, width_m, origin_x, origin_y, base):
    """Generate a top-only strip; deck thickness and support piers are not inferred."""
    points=record['profile_xyz']
    if len(points)<2: return [],[],None
    # Build a normal at each centerline vertex using adjacent tangents.
    normals=[]
    for i,p in enumerate(points):
        before=points[max(0,i-1)];after=points[min(len(points)-1,i+1)]
        dx=after[0]-before[0];dy=after[1]-before[1]
        mag=math.hypot(dx,dy)
        if mag<1e-9:return [],[],None
        normals.append((-dy/mag,dx/mag))
    left=[];right=[]
    for p,n in zip(points,normals):
        left.append((p[0]+n[0]*width_m/2,p[1]+n[1]*width_m/2,p[2]))
        right.append((p[0]-n[0]*width_m/2,p[1]-n[1]*width_m/2,p[2]))
    vertices=[];uv=[]
    for i in range(len(points)-1):
        for q in (left[i],right[i],right[i+1],left[i],right[i+1],left[i+1]):
            vertices.append((q[0]-origin_x,q[1]-origin_y,q[2]-base))
    xs=[q[0] for q in left+right];ys=[q[1] for q in left+right]
    bounds=(min(xs),min(ys),max(xs),max(ys))
    if bounds[2]-bounds[0]<1e-6 or bounds[3]-bounds[1]<1e-6:return [],[],None
    for x,y,z in vertices:
        # glTF UV uses flipped V relative to OBJ's original geographic UV.
        uv.append(((x+origin_x-bounds[0])/(bounds[2]-bounds[0]),
                   1-(y+origin_y-bounds[1])/(bounds[3]-bounds[1])))
    return vertices,uv,bounds


def append_bridge_decks(glb, records, imagery, bounds, base, resolution,
                        rail_width, road_width, max_texture_px=2048):
    added=0
    for r in tqdm(records,desc='Exporting bridge decks',unit='bridge'):
        if not r['profile_xyz']:continue
        width=rail_width if r['type']=='railway' else road_width
        verts,uv,extent=bridge_deck_mesh(r,width,bounds.left,bounds.bottom,base)
        if not verts:continue
        xmin,ymin,xmax,ymax=extent
        w=min(max_texture_px,max(2,math.ceil((xmax-xmin)/resolution)))
        h=min(max_texture_px,max(2,math.ceil((ymax-ymin)/resolution)))
        rgb=imagery.render(extent,w,h)
        glb.add_tile(f"Bridge_{r['type']}_{r.get('osm_way_id', r.get('id', 'inferred'))}",verts,uv,Image.fromarray(rgb))
        added+=1
    return added


class StreamingGLB:
    """Write embedded textured glTF 2.0 directly, without OBJ or Blender."""
    def __init__(self, path):
        self.path = Path(path)
        self.tmp = tempfile.TemporaryFile(mode='w+b')
        self.doc = {'asset': {'version': '2.0', 'generator': 'Adaptive Terrain Direct GLB'},
                    'scene': 0, 'scenes': [{'nodes': []}], 'nodes': [],
                    'meshes': [], 'materials': [], 'textures': [], 'images': [],
                    'samplers': [{'magFilter': 9729, 'minFilter': 9987, 'wrapS': 33071, 'wrapT': 33071}],
                    'bufferViews': [], 'accessors': []}
        self.count = 0

    def add_buffer(self, data, target=None):
        offset = self.tmp.tell()
        self.tmp.write(data)
        self.tmp.write(b'\x00' * ((-len(data)) % 4))
        view = {'buffer': 0, 'byteOffset': offset, 'byteLength': len(data)}
        if target is not None:
            view['target'] = target
        index = len(self.doc['bufferViews'])
        self.doc['bufferViews'].append(view)
        return index

    def add_tile(self, name, vertices, uv, image):
        if not vertices:
            return
        positions = np.asarray(vertices, dtype='<f4').reshape((-1, 3))
        texcoords = np.asarray(uv, dtype='<f4').reshape((-1, 2))
        if len(positions) != len(texcoords) or len(positions) % 3:
            raise ValueError('GLB tile must contain triangle vertices and matching UVs')
        # Blender OBJ -> GLB convention: Z-up source becomes glTF Y-up.
        positions = positions[:, [0, 2, 1]].copy()
        positions[:, 2] *= -1
        pview = self.add_buffer(positions.tobytes(), 34962)
        tview = self.add_buffer(texcoords.tobytes(), 34962)
        image_buffer = io.BytesIO()
        image.save(image_buffer, format='PNG')
        iview = self.add_buffer(image_buffer.getvalue())
        image_id = len(self.doc['images'])
        self.doc['images'].append({'bufferView': iview, 'mimeType': 'image/png', 'name': name})
        texture_id = len(self.doc['textures'])
        self.doc['textures'].append({'sampler': 0, 'source': image_id})
        material_id = len(self.doc['materials'])
        self.doc['materials'].append({'name': name, 'doubleSided': True,
            'pbrMetallicRoughness': {'baseColorTexture': {'index': texture_id},
                                     'baseColorFactor': [1,1,1,1],
                                     'metallicFactor': 0, 'roughnessFactor': 1}})
        pa = len(self.doc['accessors'])
        self.doc['accessors'].append({'bufferView': pview, 'componentType': 5126,
            'count': len(positions), 'type': 'VEC3',
            'min': positions.min(axis=0).tolist(), 'max': positions.max(axis=0).tolist()})
        ta = len(self.doc['accessors'])
        self.doc['accessors'].append({'bufferView': tview, 'componentType': 5126,
            'count': len(texcoords), 'type': 'VEC2'})
        mesh_id = len(self.doc['meshes'])
        self.doc['meshes'].append({'name': name, 'primitives': [{
            'attributes': {'POSITION': pa, 'TEXCOORD_0': ta},
            'material': material_id, 'mode': 4}]})
        node_id = len(self.doc['nodes'])
        self.doc['nodes'].append({'name': name, 'mesh': mesh_id})
        self.doc['scenes'][0]['nodes'].append(node_id)
        self.count += len(positions)

    def finish(self):
        size = self.tmp.tell()
        self.doc['buffers'] = [{'byteLength': size}]
        js = json.dumps(self.doc, separators=(',', ':')).encode('utf-8')
        js += b' ' * ((-len(js)) % 4)
        total = 12 + 8 + len(js) + 8 + size
        if total >= 2**32:
            raise ValueError('GLB exceeds the 4 GiB format limit; reduce geometry or texture scale')
        self.tmp.seek(0)
        with self.path.open('wb') as output:
            output.write(struct.pack('<4sII', b'glTF', 2, total))
            output.write(struct.pack('<I4s', len(js), b'JSON'))
            output.write(js)
            output.write(struct.pack('<I4s', size, b'BIN\x00'))
            shutil.copyfileobj(self.tmp, output, length=8*1024*1024)
        self.tmp.close()
        print(f'GLB exported: {self.path} ({total/1024**2:.1f} MiB, {self.count:,} vertices)', flush=True)


def export_corridor_tiled(out, dem, imagery_sources, bounds, keys, elevations, valid,
                          faces, step, base, corridor, resolution, tile_pixels,
                          workers=1, clip_batch_size=4000, texture_scale=1.0, output_format="obj",
                          bridges=None, rail_bridge_width=6.0, road_bridge_width=12.0,
                          inferred_bridges=None, mask_inferred_ground=False, grouped_decks=None):
    """Clip faces in batches; avoid intersections for interior faces; parallel on request."""
    from shapely import to_wkb
    b=bounds
    tile_m=resolution*tile_pixels
    x0,y0=b.left,b.bottom
    xy=[(min(b.right,x0+ix*step),min(b.top,y0+iy*step)) for ix,iy in keys]
    tile_polygons=defaultdict(list)
    batches=(faces[i:i+clip_batch_size] for i in range(0,len(faces),clip_batch_size))
    total=math.ceil(len(faces)/clip_batch_size)
    start=time.perf_counter()
    init=(xy,valid,to_wkb(corridor),x0,y0,tile_m,b.right,b.top)
    if workers == 1:
        _init_clip_worker(*init)
        iterator=map(_clip_batch,batches)
        for result in tqdm(iterator,total=total,desc='Clipping terrain batches',unit='batch'):
            for key,items in result.items(): tile_polygons[key].extend(items)
    else:
        # Windows uses spawn: top-level functions and __main__ guard are required.
        with ProcessPoolExecutor(max_workers=workers,initializer=_init_clip_worker,initargs=init) as pool:
            iterator=pool.map(_clip_batch,batches,chunksize=1)
            for result in tqdm(iterator,total=total,desc='Clipping terrain batches',unit='batch'):
                for key,items in result.items(): tile_polygons[key].extend(items)
    print(f'Clipping completed in {time.perf_counter()-start:.1f}s using {workers} worker(s)',flush=True)
    if not tile_polygons:
        raise ValueError('No valid corridor terrain faces. Check DEM coverage and corridor location.')
    is_glb = output_format == 'glb'
    if not is_glb:
        textures=out/'textures'; textures.mkdir(exist_ok=True)
    material_lines=[]
    vertex_index=0
    glb = StreamingGLB(out/'terrain.glb') if is_glb else None
    # Spatially index inferred spans for masking duplicate aerial road/rail imagery.
    mask_shapes = []
    if mask_inferred_ground and (grouped_decks or inferred_bridges):
        from shapely.strtree import STRtree
        if grouped_decks:
            mask_shapes.extend(g['footprint'] for g in grouped_decks)
        else:
            for crossing in inferred_bridges:
                coords = [(p[0],p[1]) for p in crossing['profile_xyz']]
                if len(coords) >= 2:
                    mask_shapes.append(LineString(coords).buffer(rail_bridge_width/2))
        mask_tree = STRtree(mask_shapes) if mask_shapes else None
    else:
        mask_tree = None
    obj = None
    try:
        if not is_glb:
            obj = (out/'terrain.obj').open('w', encoding='utf8', buffering=1024*1024)
            obj.write('mtllib terrain.mtl\n')
        with VirtualImagery(imagery_sources, dem.crs) as imagery:
            for (ix,iy),pieces in tqdm(sorted(tile_polygons.items()),desc='Exporting texture tiles',unit='tile'):
                tx0,ty0=x0+ix*tile_m,y0+iy*tile_m
                tx1,ty1=min(tx0+tile_m,b.right),min(ty0+tile_m,b.top)
                w=max(2,math.ceil((tx1-tx0)/resolution*texture_scale))
                h=max(2,math.ceil((ty1-ty0)/resolution*texture_scale))
                rgb=imagery.render((tx0,ty0,tx1,ty1),w,h)
                if mask_tree is not None:
                    from rasterio.features import rasterize
                    tile_box = box(tx0,ty0,tx1,ty1)
                    nearby = mask_tree.query(tile_box)
                    shapes = [(mask_shapes[int(k)], 1) for k in nearby if mask_shapes[int(k)].intersects(tile_box)]
                    if shapes:
                        mask = rasterize(shapes, out_shape=(h,w),
                                         transform=from_bounds(tx0,ty0,tx1,ty1,w,h), fill=0)
                        rgb[mask.astype(bool)] = (35,35,35)
                texname=f'corridor_{ix}_{iy}.png'
                mat=f'Corridor_{ix}_{iy}'
                if not is_glb:
                    Image.fromarray(rgb).save(textures/texname)
                    material_lines.append(f'newmtl {mat}\nKd 1 1 1\nmap_Kd textures/{texname}\n')
                    obj.write(f'o Tile_{ix}_{iy}\nusemtl {mat}\n')
                tile_vertices=[]
                tile_uv=[]
                for part,ids in pieces:
                    a,c,d=ids
                    xA,yA=xy[a-1];xB,yB=xy[c-1];xC,yC=xy[d-1]
                    denom=(yB-yC)*(xA-xC)+(xC-xB)*(yA-yC)
                    if abs(denom)<1e-12:continue
                    if len(part.interiors)==0 and len(part.exterior.coords)==4:
                        triangles=(part,)
                    else:
                        triangles=constrained_delaunay_triangles(part).geoms
                    for triangle in triangles:
                        if triangle.area<1e-10:continue
                        coords=list(triangle.exterior.coords)[:3]
                        # Preserve CCW XY winding for upward-facing terrain.
                        cross=((coords[1][0]-coords[0][0])*(coords[2][1]-coords[0][1])
                               -(coords[1][1]-coords[0][1])*(coords[2][0]-coords[0][0]))
                        if cross < 0:
                            coords[1],coords[2]=coords[2],coords[1]
                        for x,y in coords:
                            wa=((yB-yC)*(x-xC)+(xC-xB)*(y-yC))/denom
                            wb=((yC-yA)*(x-xC)+(xA-xC)*(y-yC))/denom
                            wc=1-wa-wb
                            z=wa*elevations[a-1]+wb*elevations[c-1]+wc*elevations[d-1]
                            u=(x-tx0)/(tx1-tx0)
                            v=(y-ty0)/(ty1-ty0)
                            if is_glb:
                                tile_vertices.append((x-x0, y-y0, z-base))
                                tile_uv.append((u,1.0-v))
                            else:
                                obj.write(f'v {x-x0:.5f} {y-y0:.5f} {z-base:.5f}\n')
                                obj.write(f'vt {u:.9f} {v:.9f}\n')
                        if not is_glb:
                            obj.write(f'f {vertex_index+1}/{vertex_index+1} {vertex_index+2}/{vertex_index+2} {vertex_index+3}/{vertex_index+3}\n')
                        vertex_index+=3
                if is_glb:
                    glb.add_tile(mat, tile_vertices, tile_uv, Image.fromarray(rgb))
            if is_glb and bridges:
                n=append_bridge_decks(glb,bridges,imagery,b,base,
                       resolution/texture_scale,rail_bridge_width,road_bridge_width)
                print(f'Added {n} OSM-tagged bridge decks to GLB',flush=True)
            if is_glb and grouped_decks:
                n=append_group_decks(glb,grouped_decks,imagery,b,base,
                                     resolution/texture_scale)
                print(f'Added {n} grouped inferred crossing decks to GLB',flush=True)
        if is_glb:
            glb.finish()
        else:
            (out/'terrain.mtl').write_text('\n'.join(material_lines),encoding='utf8')
    finally:
        if obj is not None:
            obj.close()
        if glb is not None:
            glb.tmp.close()
    print(f'Corridor export: {len(tile_polygons):,} texture tiles, {vertex_index:,} vertices ({output_format})',flush=True)
    return {'tiles':len(tile_polygons),'vertices':vertex_index}



def resolve_infrastructure_path(explicit_path, network_path, output_path):
    """Find the Overpass infrastructure JSON without depending on the working directory."""
    network = Path(network_path).expanduser().resolve()
    output = Path(output_path).expanduser().resolve()
    script_dir = Path(__file__).resolve().parent

    if explicit_path:
        chosen = Path(explicit_path).expanduser()
        candidates = [chosen] if chosen.is_absolute() else [
            Path.cwd() / chosen, script_dir / chosen, network.parent / chosen,
        ]
    else:
        candidates = [
            network.parent / 'infrastructure_raw_osm.json',
            output.parent / 'osm_output' / 'infrastructure_raw_osm.json',
            script_dir / 'osm_output' / 'infrastructure_raw_osm.json',
            Path.cwd() / 'osm_output' / 'infrastructure_raw_osm.json',
            script_dir / 'infrastructure_raw_osm.json',
        ]

    checked = []
    for candidate in candidates:
        candidate = candidate.resolve()
        if candidate in checked:
            continue
        checked.append(candidate)
        if candidate.is_file():
            print(f'Using infrastructure JSON: {candidate}', flush=True)
            return candidate
    raise FileNotFoundError(
        'Bridge-aware infrastructure JSON not found. Searched:\n  '
        + '\n  '.join(map(str, checked))
        + '\nGenerate infrastructure_raw_osm.json using the updated Overpass query, '
        'or pass --infrastructure with its exact path.'
    )


def main():
    p = argparse.ArgumentParser(description='Adaptive textured terrain OBJ refined around GeoPackage roads/railways')
    p.add_argument('--format', choices=['obj', 'glb'], default='obj', help='Terrain output format; GLB embeds textures')
    p.add_argument('--boundary', help='WGS84 project polygon used to filter DEM sources and select target CRS')
    p.add_argument('--dem-vrt-buffer', type=float, default=500, help='DEM extent padding around project bounds, meters')
    p.add_argument('--dem-vrt-resolution', type=float, default=1, help='Virtual DEM target resolution in meters')
    p.add_argument('--dem', required=True, help='DEM GeoTIFF or folder of DEM TIFFs')
    p.add_argument('--imagery', help='Imagery GeoTIFF or folder of imagery TIFFs (not required with --network-only)')
    p.add_argument('--rebuild-mosaics', action='store_true', help='Rebuild the DEM VRT index (imagery is virtual)')
    p.add_argument('--gpkg', help='GPKG, raw Overpass OSM JSON, GeoJSON, or KML input (legacy flag)')
    p.add_argument('--network', help='Network vector file: .gpkg, .json, .geojson, or .kml')
    p.add_argument('--infrastructure', help='Raw infrastructure_raw_osm.json from bridge-aware Overpass query')
    p.add_argument('--bridges', action='store_true', help='Estimate OSM-tagged bridge decks')
    p.add_argument('--rail-inference-mode', choices=['legacy','topology'], default='topology')
    p.add_argument('--rail-stable-approach', type=float, default=20.0)
    p.add_argument('--rail-max-turn', type=float, default=90.0)
    p.add_argument('--deck-parallel-angle', type=float, default=15.0)
    p.add_argument('--infer-rail-crossings', action='store_true', help='Infer railway bridge spans from DEM grade anomalies and export shared Z profiles')
    p.add_argument('--mask-inferred-ground', action='store_true', help='Darken imagery under inferred rail bridge decks')
    p.add_argument('--rail-sample-spacing', type=float, default=5.0)
    p.add_argument('--rail-boundary-spacing', type=float, default=0.5, help='Horizontal sampling interval around suspected DEM drops (m)')
    p.add_argument('--rail-boundary-search', type=float, default=30.0, help='Distance to inspect around detected anomalies (m)')
    p.add_argument('--deck-group-gap', type=float, default=5.0, help='Merge compatible deck footprints separated by up to this distance (m)')
    p.add_argument('--deck-group-z-tolerance', type=float, default=float('inf'), help='Maximum vertical separation for grouping crossing decks (m)')
    p.add_argument('--rail-max-grade', type=float, default=0.03, help='Fraction: 0.03 = 3 percent')
    p.add_argument('--rail-min-span', type=float, default=10.0)
    p.add_argument('--rail-max-span', type=float, default=150.0)
    p.add_argument('--rail-min-dem-drop', type=float, default=1.5)
    p.add_argument('--rail-sag-change-per-100ft', type=float, default=0.05)
    p.add_argument('--rail-crest-change-per-100ft', type=float, default=0.10)
    p.add_argument('--bridge-approach-m', type=float, default=12.0)
    p.add_argument('--rail-bridge-width', type=float, default=6.0)
    p.add_argument('--road-bridge-width', type=float, default=12.0)
    p.add_argument('--bridge-review-clearance', type=float, default=0.0,
                   help='Flag inferred deck elevations less than this many meters above sampled ground')
    p.add_argument('--network-only', action='store_true', help='Export only network_lines.obj from vector source; skip terrain and imagery')
    p.add_argument('--layer', action='append', help='Repeat for multiple layers; default all')
    p.add_argument('--output', default='terrain_output')
    p.add_argument('--near-spacing', type=float, default=3)
    p.add_argument('--transition-spacing', type=float, default=10)
    p.add_argument('--background-spacing', type=float, default=70)
    p.add_argument('--fine-buffer', type=float, default=50)
    p.add_argument('--transition-buffer', type=float, default=200)
    p.add_argument('--line-spacing', type=float, default=3)
    p.add_argument('--line-z-offset', type=float, default=0.5)
    p.add_argument('--max-cells', type=int, default=2_000_000)
    p.add_argument('--max-texture', type=int, default=8192)
    p.add_argument('--base-elevation', type=float)
    p.add_argument('--workers', type=int, default=8, help='Clipping worker processes (1 disables multiprocessing)')
    p.add_argument('--clip-batch-size', type=int, default=4000)
    p.add_argument('--refine-workers', type=int, default=12, help='CPU processes for quadtree refinement')
    p.add_argument('--max-elevation-error', type=float, default=None, help='Optional sampled vertical error tolerance in meters; experimental')
    p.add_argument('--flat-spacing', type=float, default=20, help='Maximum cell width eligible for error-based early stop (m)')
    p.add_argument('--texture-scale', type=float, default=1.0, help='Texture linear resolution multiplier (0,1]')
    p.add_argument('--corridor-only', action='store_true', help='Export only terrain inside the rail corridor buffer')
    p.add_argument('--corridor-width', type=float, default=400, help='Total corridor width in meters')
    p.add_argument('--texture-resolution', type=float, default=0.5, help='Texture meters per pixel in corridor mode')
    p.add_argument('--texture-tile-size', type=int, default=2048, help='Maximum texture tile dimension in pixels')
    p.add_argument('--use-dem-line-z', action='store_true', help='Override any existing 3D GPKG Z values with DEM samples')
    args = p.parse_args()
    vector_path = args.network or args.gpkg
    if not vector_path:
        p.error('Provide --network or --gpkg')
    if (args.bridges or args.infer_rail_crossings) and (not args.corridor_only or args.format != 'glb'):
        p.error('--bridges currently requires --corridor-only --format glb')
    if min(args.bridge_approach_m,args.rail_bridge_width,args.road_bridge_width,args.rail_sample_spacing,args.rail_boundary_spacing,args.rail_min_span,args.rail_max_span)<=0 or args.rail_min_span >= args.rail_max_span or args.rail_min_dem_drop <= 0 or args.rail_max_grade <= 0:
        p.error('Bridge approach distance and widths must be positive')
    if not args.network_only and not args.imagery:
        p.error('--imagery is required unless --network-only is specified')
    if not (0 < args.near_spacing <= args.transition_spacing <= args.background_spacing):
        p.error('Require 0 < near-spacing <= transition-spacing <= background-spacing')
    if not (0 <= args.fine_buffer < args.transition_buffer):
        p.error('Require 0 <= fine-buffer < transition-buffer')
    if args.max_texture < 2 or args.line_spacing <= 0 or args.max_cells <= 0:
        p.error('Invalid max-texture, line-spacing or max-cells')
    if args.workers < 1 or args.refine_workers < 1 or args.clip_batch_size < 1:
        p.error('workers and clip-batch-size must be positive')
    if not (0 < args.texture_scale <= 1) or args.flat_spacing <= 0 or (args.max_elevation_error is not None and args.max_elevation_error < 0):
        p.error('Invalid texture-scale, flat-spacing or max-elevation-error')
    if args.corridor_width <= 0 or args.texture_resolution <= 0 or args.texture_tile_size < 2:
        p.error('Corridor width, texture resolution and texture tile size must be positive')
    out = Path(args.output); out.mkdir(parents=True,exist_ok=True)
    # Resolve before expensive DEM sampling and mesh generation.
    infrastructure = (resolve_infrastructure_path(args.infrastructure, vector_path, out)
                      if args.bridges and not args.network_only else None)
    if args.dem_vrt_buffer < 0 or args.dem_vrt_resolution <= 0:
        p.error('Invalid DEM VRT buffer or resolution')
    dem_path, dem_sources = resolve_raster_input(args.dem, 'DEM', out, refresh=args.rebuild_mosaics,
        boundary_path=args.boundary, boundary_buffer=args.dem_vrt_buffer, vrt_resolution=args.dem_vrt_resolution)
    with rasterio.open(dem_path) as dem:
        imagery_path = None
        imagery_sources = []
        if not args.network_only:
            imagery_sources = resolve_imagery_virtual(args.imagery, dem.crs)
        if dem.crs is None or not dem.crs.is_projected or 'met' not in (dem.crs.linear_units or '').lower():
            raise ValueError('DEM must use a projected CRS in meters')
        b = dem.bounds
        if args.network_only:
            lines, layers = load_vector_lines(vector_path, args.layer, dem.crs, preserve_original_crs=True)
            # Match the normal terrain export origin and baseline without generating a mesh.
            # Rasterio's masked minimum excludes NoData pixels.
            if args.base_elevation is not None:
                base = args.base_elevation
            else:
                minimum = None
                for _, window in dem.block_windows(1):
                    block = dem.read(1, window=window, masked=True)
                    if block.count():
                        value = float(block.min())
                        minimum = value if minimum is None else min(minimum, value)
                if minimum is None:
                    raise ValueError('DEM contains no valid elevations')
                base = minimum
            if args.use_dem_line_z:
                raise ValueError("--use-dem-line-z is incompatible with --network-only exact vertices")
            export_lines(lines, dem, out, b.left, b.bottom, base,
                         args.line_spacing, 0.0, True, exact_vertices=True)
            (out / 'georeference.json').write_text(json.dumps({
                'crs': str(dem.crs), 'origin_x': b.left, 'origin_y': b.bottom,
                'base_elevation': base, 'layers': layers,
                'existing_line_z_preserved': not args.use_dem_line_z,
                'network_only': True, 'original_network_vertices': True,
                'vertex_count_modified': False, 'line_z_offset': 0.0,
                'source_network': str(vector_path),
                'xy_reprojected_to_dem_crs': Path(vector_path).suffix.lower() != '.gpkg'
            }, indent=2), encoding='utf-8')
            print(f'Done: network-only export at {out.resolve()}', flush=True)
            return
        tree,layers,lines = read_corridors(vector_path,args.layer,dem.crs)
        corridor = None
        if args.corridor_only:
            print('Building corridor polygon...', flush=True)
            corridor = unary_union([g.buffer(args.corridor_width / 2, quad_segs=4) for g in tqdm(lines, desc='Buffering lines', unit='line')])
            corridor = corridor.intersection(box(*dem.bounds))
            if corridor.is_empty:
                raise ValueError('Corridor does not overlap DEM')
            if corridor.geom_type == 'MultiPolygon':
                # One continuous mesh region only, as requested. Do not create separate terrain islands.
                corridor = max(corridor.geoms, key=lambda g: g.area)
                print('Corridor has multiple components: using largest connected polygon only.', flush=True)
            elif corridor.geom_type == 'GeometryCollection':
                polys = [g for g in corridor.geoms if g.geom_type == 'Polygon']
                if not polys: raise ValueError('No polygonal corridor inside DEM')
                corridor = max(polys, key=lambda g: g.area)
            print(f'Corridor area: {corridor.area / 1e6:.3f} km2', flush=True)
        inferred = None
        inferred_decks = []
        grouped_decks = []
        if args.infer_rail_crossings:
            cfg = {'sample_spacing_m':args.rail_sample_spacing,
                   'grade_limit':args.rail_max_grade,
                   'min_span_m':args.rail_min_span,
                   'max_span_m':args.rail_max_span,
                   'min_depth_m':args.rail_min_dem_drop,
                   'sag_change_pct_per_100ft':args.rail_sag_change_per_100ft,
                   'crest_change_pct_per_100ft':args.rail_crest_change_per_100ft,
                   'boundary_search_m':args.rail_boundary_search,
                   'boundary_spacing_m':args.rail_boundary_spacing}
            print('Inferring railway crossings from DEM profiles...',flush=True)
            if args.rail_inference_mode == 'topology':
                cfg.update(sample_spacing_m=1.0,stable_m=args.rail_stable_approach,
                           max_turn_deg=args.rail_max_turn,max_states=250000)
                inferred = infer_topology_profiles(vector_path,dem,cfg)
            else:
                inferred = infer_profiles(vector_path,dem,cfg)
            save_profiles(out,inferred)
            inferred_decks = [dict(c, type='railway') for c in inferred['crossings']
                              if LineString([(p[0],p[1]) for p in c['profile_xyz']]).intersects(corridor)]
            print(f'Inferred {len(inferred_decks)} railway spans; review inferred_crossings.csv',flush=True)
        cells,step = build_cells((b.left,b.bottom,b.right,b.top),tree,args.near_spacing,
                                 args.transition_spacing,args.background_spacing,
                                 args.fine_buffer,args.transition_buffer,args.max_cells,
                                 args.corridor_only,args.corridor_width/2,
                                 workers=args.refine_workers,dem_path=dem_path,
                                 max_error=args.max_elevation_error,flat_spacing=args.flat_spacing,
                                 corridor_bounds=corridor.bounds if corridor is not None else None)
        print(f'Adaptive cells: {len(cells):,}; building stitched topology...',flush=True)
        vertices,faces = mesh_topology(cells)
        print(f'Vertices: {len(vertices):,}; faces: {len(faces):,}; sampling DEM...',flush=True)
        keys = list(vertices)
        # DEM sampling in bounded batches; sample at actual vertex locations.
        elevations = sample_dem_blockwise(dem, keys, b, step)
        valid = np.isfinite(elevations)
        if not valid.any():
            raise ValueError('No valid DEM elevations at mesh vertices')
        base = float(np.min(elevations[valid])) if args.base_elevation is None else args.base_elevation
        bridge_records=[]
        if args.bridges:
            bridge_records=bridge_profiles(infrastructure,dem,corridor,args.bridge_approach_m,
                                           args.bridge_review_clearance)
            save_bridge_profiles(out,bridge_records,dem.crs)
            # Keep inferred spans for grouping. Do not discard an entire inferred
            # span simply because a portion overlaps an OSM-tagged bridge.
            print(f'Bridge candidates: {len(bridge_records)}; review bridge_review.csv',flush=True)
        if args.infer_rail_crossings:
            grouped_decks = group_crossings(inferred_decks, width=args.rail_bridge_width,
                                            gap=args.deck_group_gap,
                                            vertical_tolerance=args.deck_group_z_tolerance,
                                            parallel_angle=args.deck_parallel_angle)
            save_groups(out, grouped_decks, dem.crs)
            print(f'Grouped {len(inferred_decks)} inferred spans into {len(grouped_decks)} deck surfaces', flush=True)
        if bridge_records and grouped_decks:
            # Suppress duplicate OSM-tagged RAIL bridge surfaces where the
            # grouped inferred deck already covers the same centerline.
            # Keep road bridges and non-overlapping rail bridges.
            from shapely.ops import unary_union as _union
            cover = _union([g['footprint'] for g in grouped_decks])
            kept_records = []
            suppressed = 0
            for record in bridge_records:
                if record['type'] != 'railway' or len(record.get('profile_xyz', [])) < 2:
                    kept_records.append(record)
                    continue
                center = LineString([(p[0],p[1]) for p in record['profile_xyz']])
                overlap = center.intersection(cover).length / max(center.length, 1e-9)
                if overlap >= 0.30:
                    suppressed += 1
                else:
                    kept_records.append(record)
            bridge_records = kept_records
            print(f'Suppressed {suppressed} duplicate OSM railway bridge decks; '
                  f'exporting {len(bridge_records)} remaining tagged decks', flush=True)
        if args.corridor_only:
            stats = export_corridor_tiled(out, dem, imagery_sources, b, keys, elevations, valid, faces,
                                          step, base, corridor, args.texture_resolution,
                                          args.texture_tile_size, args.workers, args.clip_batch_size, args.texture_scale, args.format,
                                          bridge_records, args.rail_bridge_width, args.road_bridge_width,
                                          inferred_decks, args.mask_inferred_ground, grouped_decks)
            tw = th = 0
        else:
            if args.format == "glb":
                raise ValueError("Direct GLB currently requires --corridor-only")
            with VirtualImagery(imagery_sources, dem.crs) as imagery:
                # Keep existing max-texture behavior without creating a source mosaic.
                ratio = min(1.0, args.max_texture / max(dem.width, dem.height))
                tw, th = max(2, round(dem.width*ratio)), max(2, round(dem.height*ratio))
                rgb = imagery.render((b.left,b.bottom,b.right,b.top),tw,th)
            Image.fromarray(rgb).save(out/'terrain_texture.png')
            with (out/'terrain.obj').open('w',encoding='utf8') as f:
                f.write('mtllib terrain.mtl\no Terrain\n')
                for (ix,iy),z in tqdm(zip(keys,elevations), total=len(keys), desc="Writing OBJ vertices", unit="vertex"):
                    x=min(b.right,b.left+ix*step)-b.left
                    y=min(b.top,b.bottom+iy*step)-b.bottom
                    f.write(f'v {x:.5f} {y:.5f} {float(z-base) if np.isfinite(z) else 0:.5f}\n')
                for ix,iy in tqdm(keys, desc="Writing texture UVs", unit="vertex"):
                    x=min(b.right,b.left+ix*step)
                    y=min(b.top,b.bottom+iy*step)
                    f.write(f'vt {(x-b.left)/(b.right-b.left):.9f} {(y-b.bottom)/(b.top-b.bottom):.9f}\n')
                f.write('usemtl TerrainMaterial\n')
                for a,c,d in tqdm(faces, desc="Writing OBJ faces", unit="face"):
                    if valid[a-1] and valid[c-1] and valid[d-1]:
                        f.write(f'f {a}/{a} {c}/{c} {d}/{d}\n')
            (out/'terrain.mtl').write_text('newmtl TerrainMaterial\nKd 1 1 1\nmap_Kd terrain_texture.png\n')
        export_lines(lines,dem,out,b.left,b.bottom,base,args.line_spacing,args.line_z_offset,not args.use_dem_line_z,rail_profile=inferred)
        (out/'georeference.json').write_text(json.dumps({
            'crs':str(dem.crs),'origin_x':b.left,'origin_y':b.bottom,
            'base_elevation':base,'layers':layers,'near_spacing':args.near_spacing,
            'transition_spacing':args.transition_spacing,'background_spacing':args.background_spacing,
            'fine_buffer':args.fine_buffer,'transition_buffer':args.transition_buffer,
            'vertices':len(vertices),'triangles':len(faces),
            'note':'Requested spacing is a maximum target; quadtree levels are powers of two.',
            'existing_line_z_preserved':not args.use_dem_line_z,
            'source_network': str(vector_path),
            'corridor_only':args.corridor_only, 'corridor_width_m':args.corridor_width,
            'texture_resolution_m_per_pixel':args.texture_resolution,
            'texture_tile_max_pixels':args.texture_tile_size,
            'clip_workers':args.workers, 'refine_workers':args.refine_workers,
            'max_elevation_error':args.max_elevation_error, 'flat_spacing':args.flat_spacing,
            'texture_scale':args.texture_scale, 'terrain_format':args.format,
            'dem_sources':dem_sources, 'imagery_sources':imagery_sources,
            'imagery_mode':'on_demand_warped_vrt',
            'bridge_aware':args.bridges, 'bridge_profiles':'bridge_profiles.json' if args.bridges else None,
            'railway_elevation_profiles':'railway_elevation_profiles.json' if args.infer_rail_crossings else None
        },indent=2))
        print(f'Done: {out.resolve()} | source mesh {len(vertices):,} vertices, {len(faces):,} triangles' + (' | corridor tiles: '+str(stats['tiles']) if args.corridor_only else f' | texture {tw}x{th}'))

if __name__ == '__main__':
    main()
