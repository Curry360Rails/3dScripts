"""Topology-aware 1 m DEM grade screening and approach-to-approach interpolation.
Estimated visual elevations only; review all crossings before operational use.
"""
import math
import json
from collections import defaultdict, deque
import numpy as np
from rasterio.warp import transform
from rail_elevation_inference import _sample


def infer_topology_profiles(osm_path, dem, cfg):
    data=json.loads(open(osm_path,encoding='utf-8-sig').read())
    elements=data['elements']
    raw={int(e['id']):(e['lon'],e['lat']) for e in elements if e['type']=='node' and 'lon' in e}
    ways=[e for e in elements if e['type']=='way' and e.get('tags',{}).get('railway')=='rail' and len(e.get('nodes',[]))>1 and all(n in raw for n in e['nodes'])]
    ids=sorted({n for w in ways for n in w['nodes']})
    xx,yy=transform('EPSG:4326',dem.crs,[raw[n][0] for n in ids],[raw[n][1] for n in ids])
    original=dict(zip(ids,zip(xx,yy)))
    # Sample every edge at <=1 m, including intermediate positions at switches.
    vertices={n:tuple(original[n]) for n in ids}; adjacency=defaultdict(list)
    next_id=-1
    for w in ways:
        for a,b in zip(w['nodes'],w['nodes'][1:]):
            p,q=original[a],original[b]; length=math.dist(p,q)
            if length<0.01:continue
            steps=max(1,math.ceil(length/cfg['sample_spacing_m']))
            previous=a
            for k in range(1,steps+1):
                if k==steps: node=b
                else:
                    node=next_id;next_id-=1
                    t=k/steps;vertices[node]=(p[0]+t*(q[0]-p[0]),p[1]+t*(q[1]-p[1]))
                d=length/steps
                adjacency[previous].append((node,d));adjacency[node].append((previous,d))
                previous=node
    all_nodes=list(vertices)
    zvals=_sample(dem,[vertices[n] for n in all_nodes]); z=dict(zip(all_nodes,map(float,zvals)))
    limit=cfg['grade_limit'];stable_m=cfg['stable_m'];max_span=cfg['max_span_m']
    min_drop=cfg['min_depth_m'];angle_cos=math.cos(math.radians(cfg['max_turn_deg']))
    def direction(a,b):
        x,y=vertices[a];u,v=vertices[b];d=math.hypot(u-x,v-y)
        return ((u-x)/d,(v-y)/d) if d else (0,0)
    def outward(anchor,blocked):
        # Each state is a directed walk. No reversal/acute-angle switch traversal.
        first=direction(blocked,anchor)
        queue=deque([(anchor,blocked,first,0.0,0.0,[anchor],frozenset([(blocked,anchor)]))])
        best=None; seen=set(); explored=0
        while queue and explored<cfg['max_states']:
            cur,prev,heading,travel,stable,path,visited=queue.popleft();explored+=1
            if stable>=stable_m:
                return path,travel
            if travel>=max_span:continue
            for nxt,d in adjacency[cur]:
                if nxt==prev or (cur,nxt) in visited:continue
                ndir=direction(cur,nxt)
                if heading[0]*ndir[0]+heading[1]*ndir[1]<angle_cos:continue
                if not(math.isfinite(z[cur]) and math.isfinite(z[nxt])):continue
                ok=abs(z[nxt]-z[cur])/d<=limit
                newstable=stable+d if ok else 0.0
                newtravel=travel+d
                # quantize state to avoid exponential repeated paths
                state=(cur,nxt,int(newstable),int(newtravel/3))
                if state in seen:continue
                seen.add(state)
                queue.append((nxt,cur,ndir,newtravel,newstable,path+[nxt],visited|{(cur,nxt)}))
        return None
    # Search from both sides of each bad-grade edge, then validate compatible approaches.
    bad=[]
    for a in adjacency:
        for b,d in adjacency[a]:
            if a>=b:continue
            if math.isfinite(z[a]) and math.isfinite(z[b]) and abs(z[b]-z[a])/d>limit:
                bad.append((a,b))
    spans=[]; used=set()
    for a,b in bad:
        if (a,b) in used:continue
        left=outward(a,b);right=outward(b,a)
        if left is None or right is None:continue
        lp,_=left;rp,_=right
        # Stable approach is the final 20 m of each outward search; anchor at its near end.
        def anchor(path):
            length=0.0
            for k in range(len(path)-1,0,-1):
                length+=math.dist(vertices[path[k]],vertices[path[k-1]])
                if length>=stable_m:return k-1
            return 0
        la=lp[anchor(lp)];ra=rp[anchor(rp)]
        # Use directed graph path from left stable boundary through anomaly to right boundary.
        path=list(reversed(lp[:lp.index(la)+1]))+[b]+rp[1:rp.index(ra)+1]
        # If stable section starts directly at the anomaly, expand via detected bad runs.
        if len(path)<2:continue
        dist=[0.0]
        for u,v in zip(path,path[1:]):dist.append(dist[-1]+math.dist(vertices[u],vertices[v]))
        length=dist[-1]
        if not(cfg['min_span_m']<=length<=max_span):continue
        za,zb=z[path[0]],z[path[-1]]
        if abs(zb-za)/length>limit:continue
        expected=np.interp(dist,[0,length],[za,zb]);observed=np.array([z[n] for n in path])
        if np.max(np.abs(expected-observed))<min_drop:continue
        spans.append((path,dist,expected))
        for u,v in zip(path,path[1:]):used.add(tuple(sorted((u,v))))
    corrected=defaultdict(list); crossings=[]
    for i,(path,dist,expected) in enumerate(spans,1):
        for n,h in zip(path,expected):corrected[n].append(float(h))
        profile=[[float(vertices[n][0]),float(vertices[n][1]),float(h)] for n,h in zip(path,expected)]
        crossings.append({'id':f'topology_{i}','way_ids':[],'profile_xyz':profile,
            'start_xyz':profile[0],'end_xyz':profile[-1], 'length_m':float(dist[-1]),
            'max_dem_drop_m':float(max(abs(z[n]-h) for n,h in zip(path,expected))),
            'status':'inferred_review_required','source':'topology-aware 20 m stable approaches'})
    nodes={}
    for n in ids:
        raw_z=z[n]
        if not math.isfinite(raw_z) and n not in corrected:continue
        height=float(np.median(corrected[n])) if n in corrected else float(raw_z)
        nodes[str(n)]={'xy':list(map(float,vertices[n])),
                       'dem_z_m':float(raw_z) if math.isfinite(raw_z) else None,
                       'corrected_z_m':height,
                       'delta_z_m':height-raw_z if math.isfinite(raw_z) else None}
    return {'crs':str(dem.crs),'method':'topology-aware 1m stable approaches',
            'config':cfg,'nodes':nodes,'crossings':crossings,
            'rail_ways':len(ways),'chains_processed':len(ways),
            'bad_grade_edges':len(bad)}
